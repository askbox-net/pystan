d <- read.csv("./data3a.csv")
source("../COMMON.R")
