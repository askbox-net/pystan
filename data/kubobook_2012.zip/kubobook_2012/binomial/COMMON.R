source("../COMMON.R")
d <- read.csv("data4a.csv")

width  <- 3.5 # inch
height <- 2.8 # inch

