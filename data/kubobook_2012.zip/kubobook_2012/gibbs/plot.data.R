source("COMMON.R")

plot.frame("data1", width = 3, height = 3)
add.original()
add.xy()
dev.off()

